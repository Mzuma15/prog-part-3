package com.mycompany.programminparttwo;

import java.util.Scanner;
import java.util.List;

public class ProgramminPartTwo {
    private static Scanner scanner = new Scanner(System.in);
    private static Login registeredUser = null;
    private static Message messageService = new Message();
    
    public static void main(String[] args) {
        System.out.println("=== Registration and Login System ===\n");
        
        boolean exit = false;
        while (!exit) {
            System.out.println("\n--- Main Menu ---");
            System.out.println("1. Register");
            System.out.println("2. Login");
            System.out.println("3. Exit");
            System.out.print("Choose an option: ");
            
            int choice = getIntInput();
            
            switch (choice) {
                case 1:
                    register();
                    break;
                case 2:
                    login();
                    if (registeredUser != null && registeredUser.loginUser(getLastEnteredUsername(), getLastEnteredPassword())) {
                        showMessagingMenu();
                    }
                    break;
                case 3:
                    exit = true;
                    System.out.println("Goodbye!");
                    break;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
        scanner.close();
    }
    
    // Store last entered credentials for login check
    private static String lastUsername = "";
    private static String lastPassword = "";
    
    private static String getLastEnteredUsername() {
        return lastUsername;
    }
    
    private static String getLastEnteredPassword() {
        return lastPassword;
    }
    
    private static void showMessagingMenu() {
        int menuOption = 0;
        
        while (menuOption != 5) {
            System.out.println("\n=== Messaging System ===");
            System.out.println("1. Send Messages");
            System.out.println("2. View Sent Messages");
            System.out.println("3. Stored Messages Menu");
            System.out.println("4. Run Unit Tests");
            System.out.println("5. Exit Application");
            System.out.print("Choose an option: ");
            
            menuOption = scanner.nextInt();
            scanner.nextLine();
            
            switch (menuOption) {
                case 1:
                    sendMessages();
                    break;
                case 2:
                    viewSentMessages();
                    break;
                case 3:
                    showStoredMessagesMenu();
                    break;
                case 4:
                    runUnitTests();
                    break;
                case 5:
                    System.out.println("Thank you for using the system.\nGoodbye!");
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid option. Please select between 1 and 5.");
                    break;
            }
        }
    }
    
    private static void showStoredMessagesMenu() {
        int storedOption = 0;
        
        while (storedOption != 7) {
            System.out.println("\n=== Stored Messages Menu ===");
            System.out.println("1. Display Sender and Recipient of all Stored Messages");
            System.out.println("2. Display Longest Stored Message");
            System.out.println("3. Search for a Message by ID");
            System.out.println("4. Search for Messages by Recipient");
            System.out.println("5. Delete a Message by Hash");
            System.out.println("6. Display Full Stored Messages Report");
            System.out.println("7. Return to Main Menu");
            System.out.print("Choose an option: ");
            
            storedOption = scanner.nextInt();
            scanner.nextLine();
            
            switch (storedOption) {
                case 1:
                    messageService.displayStoredMessagesSenderRecipient();
                    break;
                case 2:
                    messageService.displayLongestStoredMessage();
                    break;
                case 3:
                    System.out.print("Enter Message ID to search: ");
                    String searchId = scanner.nextLine();
                    messageService.searchMessageById(searchId);
                    break;
                case 4:
                    System.out.print("Enter Recipient (e.g., +27838884567): ");
                    String recipient = scanner.nextLine();
                    messageService.searchMessagesByRecipient(recipient);
                    break;
                case 5:
                    System.out.print("Enter Message Hash to delete: ");
                    String hash = scanner.nextLine();
                    messageService.deleteMessageByHash(hash);
                    break;
                case 6:
                    messageService.displayStoredMessagesReport();
                    break;
                case 7:
                    System.out.println("Returning to main menu...");
                    break;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }
    
    private static void viewSentMessages() {
        System.out.println("\n=== Sent Messages ===\n");
        List<String> sentMessages = messageService.getSentMessagesList();
        
        if (sentMessages.isEmpty()) {
            System.out.println("No messages have been sent yet.");
        } else {
            for (int i = 0; i < sentMessages.size(); i++) {
                System.out.println((i + 1) + ". " + sentMessages.get(i));
            }
        }
    }
    
    private static void runUnitTests() {
        System.out.println("\n=== Running Unit Tests ===\n");
        System.out.print("Do you want to populate test data before running tests? (yes/no): ");
        String response = scanner.nextLine();
        
        if (response.equalsIgnoreCase("yes")) {
            messageService.populateTestData();
        }
        
        messageService.runAllUnitTests();
    }
    
    public static void sendMessages() {
        System.out.print("How many messages do you want to process? ");
        int messageCount = scanner.nextInt();
        scanner.nextLine();
        
        int totalSentMessages = 0;
        
        for (int i = 0; i < messageCount; i++) {
            String recipient;
            do {
                System.out.print("Enter recipient cell number for message " + (i + 1) + ": ");
                recipient = scanner.nextLine();
            } while (!messageService.checkCellNumber(recipient).equals("Valid"));
            
            String message;
            do {
                System.out.print("Enter message content for message " + (i + 1) + ": ");
                message = scanner.nextLine();
            } while (!messageService.checkMessageLength(message));
            
            String messageId = messageService.generateMessageId();
            System.out.println("Generated Message ID: " + messageId);
            
            String messageHash = messageService.generateMessageHash(messageId, i, message);
            System.out.println("Generated Message Hash: " + messageHash);
            
            String status = messageService.selectMessageAction(messageId, message, messageHash, recipient);
            
            if (status.equals("Sent")) {
                totalSentMessages++;
            }
        }
        
        System.out.println("Total messages sent: " + totalSentMessages);
    }
    
    private static void register() {
        System.out.println("\n=== Registration ===\n");
        
        System.out.print("Enter First Name: ");
        String firstName = scanner.nextLine();
        
        System.out.print("Enter Last Name: ");
        String lastName = scanner.nextLine();
        
        System.out.print("Enter Username (must contain underscore, max 5 chars): ");
        String username = scanner.nextLine();
        
        System.out.print("Enter Password (8+ chars, capital, number, special char): ");
        String password = scanner.nextLine();
        
        System.out.print("Enter Cell Phone Number (with international code, e.g., +27...): ");
        String phoneNumber = scanner.nextLine();
        
        registeredUser = new Login(firstName, lastName, username, password, phoneNumber);
        
        String registrationMessage = registeredUser.registerUser();
        System.out.println("\n" + registrationMessage);
        
        if (registrationMessage.equals("User registered successfully!")) {
            System.out.println("Your account has been created!");
        }
    }
    
    private static void login() {
        if (registeredUser == null) {
            System.out.println("\nNo user registered yet. Please register first.");
            return;
        }
        
        System.out.println("\n=== Login ===\n");
        
        System.out.print("Enter Username: ");
        lastUsername = scanner.nextLine();
        
        System.out.print("Enter Password: ");
        lastPassword = scanner.nextLine();
        
        String loginStatus = registeredUser.returnLoginStatus(lastUsername, lastPassword);
        System.out.println("\n" + loginStatus);
    }
    
    private static int getIntInput() {
        while (true) {
            try {
                return Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.print("Please enter a valid number: ");
            }
        }
    }
}