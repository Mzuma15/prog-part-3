package com.mycompany.programminparttwo;

/**
 * MessageObject class to store complete message information
 */
public class MessageObject {
    private String messageId;
    private String message;
    private String messageHash;
    private String recipient;
    private String flag; // Sent, Disregarded, Stored
    
    public MessageObject() {
        // Default constructor
    }
    
    public MessageObject(String messageId, String message, String messageHash, String recipient) {
        this.messageId = messageId;
        this.message = message;
        this.messageHash = messageHash;
        this.recipient = recipient;
    }
    
    // Getters
    public String getMessageId() {
        return messageId;
    }
    
    public String getMessage() {
        return message;
    }
    
    public String getMessageHash() {
        return messageHash;
    }
    
    public String getRecipient() {
        return recipient;
    }
    
    public String getFlag() {
        return flag;
    }
    
    // Setters
    public void setMessageId(String messageId) {
        this.messageId = messageId;
    }
    
    public void setMessage(String message) {
        this.message = message;
    }
    
    public void setMessageHash(String messageHash) {
        this.messageHash = messageHash;
    }
    
    public void setRecipient(String recipient) {
        this.recipient = recipient;
    }
    
    public void setFlag(String flag) {
        this.flag = flag;
    }
}