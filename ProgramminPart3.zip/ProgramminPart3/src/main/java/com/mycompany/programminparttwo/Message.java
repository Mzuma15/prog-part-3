package com.mycompany.programminparttwo;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

public class Message {

    Scanner scan = new Scanner(System.in);
    
    // Arrays for Part 3
    private List<String> sentMessages = new ArrayList<>();
    private List<String> disregardedMessages = new ArrayList<>();
    private List<String> storedMessages = new ArrayList<>();
    private List<String> messageHashes = new ArrayList<>();
    private List<String> messageIds = new ArrayList<>();
    
    // Store full message objects
    private List<MessageObject> allMessages = new ArrayList<>();

    /**
     * Displaying the message action options
     */
    public String selectMessageAction(String messageId, String messageText, String messageHash, String recipient) {
        // Populate arrays
        messageIds.add(messageId);
        messageHashes.add(messageHash);
        
        MessageObject msgObj = new MessageObject(messageId, messageText, messageHash, recipient);
        allMessages.add(msgObj);

        // Displaying the menu to the user
        System.out.println("\nSelect an action:");
        System.out.println("0. Send Message");
        System.out.println("1. Disregard Message");
        System.out.println("2. Store Message");

        System.out.print("User: ");
        int choice = scan.nextInt();
        scan.nextLine();

        // Using switch for the menu
        switch (choice) {
            case 0:
                sentMessages.add("Recipient: " + recipient + " | Message: " + messageText);
                System.out.println("Message successfully sent.");
                displayOnlySentMessages(messageId, messageText, messageHash, recipient);
                break;

            case 1:
                disregardedMessages.add("Recipient: " + recipient + " | Message: " + messageText);
                System.out.println("Message disregarded.");
                break;

            case 2:
                storeMessage(messageId, messageText, messageHash, recipient);
                storedMessages.add("Recipient: " + recipient + " | Message: " + messageText);
                System.out.println("Message stored successfully.");
                break;
        }
        
        // Set the flag for the message
        String[] options = {"Sent", "Disregarded", "Stored"};
        msgObj.setFlag(options[choice]);

        return options[choice];
    }

    /**
     * A method that Generates a random 10-digit message ID
     */
    public String generateMessageId() {
        Random random = new Random();
        StringBuilder builder = new StringBuilder();

        for (int i = 0; i < 10; i++) {
            builder.append(random.nextInt(10));
        }

        return builder.toString();
    }

    /**
     * A method that Generates a message hash
     */
    public String generateMessageHash(String messageId, int messageIndex, String message) {
        String prefix = messageId.substring(0, 2);
        String[] words = message.split(" ");
        String firstWord = words[0];
        String lastWord = words[words.length - 1];

        return (prefix + ":" + messageIndex + ":" + firstWord + lastWord).toUpperCase();
    }

    /**
     * A method that Checks message length 
     */
    public boolean checkMessageLength(String message) {
        if (message.length() <= 50) {
            System.out.println("Message accepted.");
            return true;
        } else {
            System.out.println("Message too long. Please keep it under 50 characters.");
            return false;
        }
    }
    
    /**
     * A method that displays only SENT messages
     */
    public String displayOnlySentMessages(String messageId, String message, String messageHash, String recipient) {
        StringBuilder build = new StringBuilder();

        build.append("-------------------------\n")
             .append("Message ID: ").append(messageId).append("\n")
             .append("Message Hash: ").append(messageHash).append("\n")
             .append("Recipient: ").append(recipient).append("\n")
             .append("User Message: ").append(message).append("\n")
             .append("-------------------------\n");

        return build.toString();
    }
    
    /**
     * A method that validates South African cell numbers
     * Must start with +27
     */
    public String checkCellNumber(String cellNumber) {
        if (cellNumber != null
                && cellNumber.startsWith("+27")
                && cellNumber.length() >= 12
                && cellNumber.matches("\\+27[0-9]+")) {

            System.out.println("Cell number successfully captured.");
            return "Valid";
        } else {
            System.out.println("Invalid cell number. It must start with +27.");
            return "Invalid";
        }
    }

    /**
     * A method that Stores messages to JSON file
     */
    public void storeMessage(String messageId, String messageText, String messageHash, String recipient) {
        File file = new File("messages.json");
        Gson gson = new Gson();

        // Create a message object to store
        MessageObject msgObj = new MessageObject(messageId, messageText, messageHash, recipient);
        
        try {
            List<MessageObject> existingMessages = loadStoredMessagesFromFile();
            existingMessages.add(msgObj);
            
            String json = gson.toJson(existingMessages);
            
            try (FileWriter writer = new FileWriter(file)) {
                writer.write(json);
            }
        } catch (IOException e) {
            System.out.println("File error: " + e.getMessage());
        }
    }
    
    /**
     * Load stored messages from JSON file into an array
     */
    public List<MessageObject> loadStoredMessagesFromFile() {
        File file = new File("messages.json");
        Gson gson = new Gson();
        List<MessageObject> messages = new ArrayList<>();
        
        if (!file.exists()) {
            return messages;
        }
        
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            StringBuilder jsonContent = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                jsonContent.append(line);
            }
            
            if (jsonContent.length() > 0) {
                // Try to parse as array
                try {
                    MessageObject[] msgArray = gson.fromJson(jsonContent.toString(), MessageObject[].class);
                    if (msgArray != null) {
                        for (MessageObject msg : msgArray) {
                            messages.add(msg);
                        }
                    }
                } catch (JsonSyntaxException e) {
                    // Try parsing as single object or legacy format
                    String[] legacyData = gson.fromJson(jsonContent.toString(), String[].class);
                    if (legacyData != null && legacyData.length == 4) {
                        MessageObject msg = new MessageObject(legacyData[0], legacyData[1], legacyData[2], legacyData[3]);
                        messages.add(msg);
                    }
                }
            }
        } catch (IOException e) {
            System.out.println("Error reading file: " + e.getMessage());
        }
        
        return messages;
    }

    /**
     * A method that Calculates total messages
     */
    public int calculateTotalMessages(int currentTotal) {
        return currentTotal;
    }
    
    // ==================== PART 3 METHODS ====================
    
    /**
     * Populate arrays with test data (Part 3, section 3)
     */
    public void populateTestData() {
        // Test Data Message 1 - Sent
        String msgId1 = generateMessageId();
        String msgHash1 = generateMessageHash(msgId1, 1, "Did you get the cake?");
        MessageObject msg1 = new MessageObject(msgId1, "Did you get the cake?", msgHash1, "+27834557896");
        msg1.setFlag("Sent");
        allMessages.add(msg1);
        messageIds.add(msgId1);
        messageHashes.add(msgHash1);
        sentMessages.add("Recipient: +27834557896 | Message: Did you get the cake?");
        
        // Test Data Message 2 - Stored
        String msgId2 = generateMessageId();
        String msgHash2 = generateMessageHash(msgId2, 2, "Where are you? You are late! I have asked you to be on time.");
        MessageObject msg2 = new MessageObject(msgId2, "Where are you? You are late! I have asked you to be on time.", msgHash2, "+27838884567");
        msg2.setFlag("Stored");
        allMessages.add(msg2);
        messageIds.add(msgId2);
        messageHashes.add(msgHash2);
        storedMessages.add("Recipient: +27838884567 | Message: Where are you? You are late! I have asked you to be on time.");
        
        // Test Data Message 3 - Disregarded
        String msgId3 = generateMessageId();
        String msgHash3 = generateMessageHash(msgId3, 3, "Yohoooo, I am at your gate.");
        MessageObject msg3 = new MessageObject(msgId3, "Yohoooo, I am at your gate.", msgHash3, "+27834484567");
        msg3.setFlag("Disregarded");
        allMessages.add(msg3);
        messageIds.add(msgId3);
        messageHashes.add(msgHash3);
        disregardedMessages.add("Recipient: +27834484567 | Message: Yohoooo, I am at your gate.");
        
        // Test Data Message 4 - Sent
        String msgId4 = generateMessageId();
        String msgHash4 = generateMessageHash(msgId4, 4, "It is dinner time !");
        MessageObject msg4 = new MessageObject(msgId4, "It is dinner time !", msgHash4, "0838884567");
        msg4.setFlag("Sent");
        allMessages.add(msg4);
        messageIds.add(msgId4);
        messageHashes.add(msgHash4);
        sentMessages.add("Recipient: 0838884567 | Message: It is dinner time !");
        
        // Test Data Message 5 - Stored
        String msgId5 = generateMessageId();
        String msgHash5 = generateMessageHash(msgId5, 5, "Ok, I am leaving without you.");
        MessageObject msg5 = new MessageObject(msgId5, "Ok, I am leaving without you.", msgHash5, "+27838884567");
        msg5.setFlag("Stored");
        allMessages.add(msg5);
        messageIds.add(msgId5);
        messageHashes.add(msgHash5);
        storedMessages.add("Recipient: +27838884567 | Message: Ok, I am leaving without you.");
        
        System.out.println("Test data populated successfully!");
    }
    
    /**
     * 2a. Display sender and recipient of all stored messages
     */
    public void displayStoredMessagesSenderRecipient() {
        System.out.println("\n=== Stored Messages - Sender and Recipient ===\n");
        List<MessageObject> stored = getStoredMessagesList();
        
        if (stored.isEmpty()) {
            System.out.println("No stored messages found.");
            return;
        }
        
        for (int i = 0; i < stored.size(); i++) {
            MessageObject msg = stored.get(i);
            System.out.println("Message " + (i + 1) + ":");
            System.out.println("  Recipient: " + msg.getRecipient());
            System.out.println("  Sender: Registered User");
            System.out.println("-------------------------");
        }
    }
    
    /**
     * 2b. Display the longest stored message
     */
    public void displayLongestStoredMessage() {
        System.out.println("\n=== Longest Stored Message ===\n");
        List<MessageObject> stored = getStoredMessagesList();
        
        if (stored.isEmpty()) {
            System.out.println("No stored messages found.");
            return;
        }
        
        MessageObject longest = stored.get(0);
        for (MessageObject msg : stored) {
            if (msg.getMessage().length() > longest.getMessage().length()) {
                longest = msg;
            }
        }
        
        System.out.println("Longest Stored Message:");
        System.out.println("  Message: " + longest.getMessage());
        System.out.println("  Length: " + longest.getMessage().length() + " characters");
        System.out.println("  Recipient: " + longest.getRecipient());
        System.out.println("  Message Hash: " + longest.getMessageHash());
    }
    
    /**
     * 2c. Search for a message ID and display recipient and message
     */
    public void searchMessageById(String searchId) {
        System.out.println("\n=== Search Message by ID ===\n");
        boolean found = false;
        
        for (MessageObject msg : allMessages) {
            if (msg.getMessageId().equals(searchId)) {
                System.out.println("Message Found!");
                System.out.println("  Message ID: " + msg.getMessageId());
                System.out.println("  Recipient: " + msg.getRecipient());
                System.out.println("  Message: " + msg.getMessage());
                found = true;
                break;
            }
        }
        
        if (!found) {
            System.out.println("Message with ID '" + searchId + "' not found.");
        }
    }
    
    /**
     * 2d. Search for all messages for a particular recipient
     */
    public void searchMessagesByRecipient(String recipient) {
        System.out.println("\n=== Search Messages for Recipient: " + recipient + " ===\n");
        boolean found = false;
        int count = 0;
        
        for (MessageObject msg : allMessages) {
            if (msg.getRecipient().equals(recipient)) {
                System.out.println("Message " + (count + 1) + ":");
                System.out.println("  Message: " + msg.getMessage());
                System.out.println("  Flag: " + msg.getFlag());
                System.out.println("  Message Hash: " + msg.getMessageHash());
                System.out.println("-------------------------");
                found = true;
                count++;
            }
        }
        
        if (!found) {
            System.out.println("No messages found for recipient '" + recipient + "'.");
        }
    }
    
    /**
     * 2e. Delete a message using the message hash
     */
    public boolean deleteMessageByHash(String messageHash) {
        System.out.println("\n=== Delete Message by Hash ===\n");
        
        for (int i = 0; i < allMessages.size(); i++) {
            if (allMessages.get(i).getMessageHash().equals(messageHash)) {
                MessageObject deleted = allMessages.remove(i);
                System.out.println("Message successfully deleted!");
                System.out.println("  Deleted Message: \"" + deleted.getMessage() + "\"");
                return true;
            }
        }
        
        System.out.println("Message with hash '" + messageHash + "' not found.");
        return false;
    }
    
    /**
     * 2f. Display report with full details of all stored messages
     */
    public void displayStoredMessagesReport() {
        System.out.println("\n==================== STORED MESSAGES REPORT ====================\n");
        List<MessageObject> stored = getStoredMessagesList();
        
        if (stored.isEmpty()) {
            System.out.println("No stored messages found.");
            return;
        }
        
        System.out.printf("%-15s %-35s %-20s %-15s%n", "Message Hash", "Message", "Recipient", "Message ID");
        System.out.println("--------------------------------------------------------------------------------");
        
        for (MessageObject msg : stored) {
            String messageDisplay = msg.getMessage().length() > 30 ? 
                msg.getMessage().substring(0, 27) + "..." : msg.getMessage();
            System.out.printf("%-15s %-35s %-20s %-15s%n", 
                msg.getMessageHash(), 
                messageDisplay, 
                msg.getRecipient(),
                msg.getMessageId());
        }
        
        System.out.println("\n================================================================\n");
    }
    
    /**
     * Helper method to get stored messages list
     */
    public List<MessageObject> getStoredMessagesList() {
        List<MessageObject> stored = new ArrayList<>();
        for (MessageObject msg : allMessages) {
            if ("Stored".equals(msg.getFlag())) {
                stored.add(msg);
            }
        }
        // Also add messages from JSON file
        List<MessageObject> jsonMessages = loadStoredMessagesFromFile();
        for (MessageObject jsonMsg : jsonMessages) {
            boolean exists = false;
            for (MessageObject msg : stored) {
                if (msg.getMessageId().equals(jsonMsg.getMessageId())) {
                    exists = true;
                    break;
                }
            }
            if (!exists) {
                stored.add(jsonMsg);
            }
        }
        return stored;
    }
    
    /**
     * Helper method to get sent messages list
     */
    public List<String> getSentMessagesList() {
        return sentMessages;
    }
    
    /**
     * Helper method to get all messages
     */
    public List<MessageObject> getAllMessages() {
        return allMessages;
    }
    
    /**
     * Helper method to get message hashes
     */
    public List<String> getMessageHashes() {
        return messageHashes;
    }
    
    /**
     * Helper method to get message IDs
     */
    public List<String> getMessageIds() {
        return messageIds;
    }
    
    /**
     * UNIT TESTS for Part 3 (Section 4)
     */
    
    /**
     * Test 1: Sent Messages array correctly populated
     * Expected to contain "Did you get the cake?" and "It is dinner time !"
     */
    public boolean testSentMessagesPopulated() {
        populateTestData();
        List<String> sent = getSentMessagesList();
        
        boolean hasMessage1 = false;
        boolean hasMessage4 = false;
        
        for (String msg : sent) {
            if (msg.contains("Did you get the cake?")) {
                hasMessage1 = true;
            }
            if (msg.contains("It is dinner time !")) {
                hasMessage4 = true;
            }
        }
        
        System.out.println("\n=== UNIT TEST: Sent Messages Array ===\n");
        System.out.println("Expected: 'Did you get the cake?' and 'It is dinner time !'");
        System.out.println("Result: " + (hasMessage1 && hasMessage4 ? "PASSED" : "FAILED"));
        
        return hasMessage1 && hasMessage4;
    }
    
    /**
     * Test 2: Display the longest Message
     * Expected to return "Where are you? You are late! I have asked you to be on time."
     */
    public boolean testLongestMessage() {
        populateTestData();
        List<MessageObject> stored = getStoredMessagesList();
        
        if (stored.isEmpty()) {
            System.out.println("\n=== UNIT TEST: Longest Message ===\n");
            System.out.println("Result: FAILED - No stored messages found");
            return false;
        }
        
        MessageObject longest = stored.get(0);
        for (MessageObject msg : stored) {
            if (msg.getMessage().length() > longest.getMessage().length()) {
                longest = msg;
            }
        }
        
        String expected = "Where are you? You are late! I have asked you to be on time.";
        boolean passed = longest.getMessage().equals(expected);
        
        System.out.println("\n=== UNIT TEST: Longest Message ===\n");
        System.out.println("Expected: \"" + expected + "\"");
        System.out.println("Actual: \"" + longest.getMessage() + "\"");
        System.out.println("Result: " + (passed ? "PASSED" : "FAILED"));
        
        return passed;
    }
    
    /**
     * Test 3: Search for messageID for message 4
     * Expected to return "0838884567" and "It is dinner time !"
     */
    public boolean testSearchMessageById() {
        populateTestData();
        
        // Find message 4 (recipient 0838884567 with message "It is dinner time !")
        String expectedRecipient = "0838884567";
        String expectedMessage = "It is dinner time !";
        String foundRecipient = null;
        String foundMessage = null;
        
        for (MessageObject msg : allMessages) {
            if (msg.getRecipient().equals(expectedRecipient) && msg.getMessage().equals(expectedMessage)) {
                foundRecipient = msg.getRecipient();
                foundMessage = msg.getMessage();
                break;
            }
        }
        
        boolean passed = expectedRecipient.equals(foundRecipient) && expectedMessage.equals(foundMessage);
        
        System.out.println("\n=== UNIT TEST: Search Message by ID ===\n");
        System.out.println("Expected Recipient: \"" + expectedRecipient + "\"");
        System.out.println("Actual Recipient: \"" + foundRecipient + "\"");
        System.out.println("Expected Message: \"" + expectedMessage + "\"");
        System.out.println("Actual Message: \"" + foundMessage + "\"");
        System.out.println("Result: " + (passed ? "PASSED" : "FAILED"));
        
        return passed;
    }
    
    /**
     * Test 4: Search all messages for recipient +27838884567
     * Expected to return both messages for that recipient
     */
    public boolean testSearchByRecipient() {
        populateTestData();
        String recipient = "+27838884567";
        List<String> foundMessages = new ArrayList<>();
        
        for (MessageObject msg : allMessages) {
            if (msg.getRecipient().equals(recipient)) {
                foundMessages.add(msg.getMessage());
            }
        }
        
        boolean containsMessage1 = foundMessages.contains("Where are you? You are late! I have asked you to be on time.");
        boolean containsMessage2 = foundMessages.contains("Ok, I am leaving without you.");
        boolean passed = containsMessage1 && containsMessage2;
        
        System.out.println("\n=== UNIT TEST: Search by Recipient ===\n");
        System.out.println("Recipient: " + recipient);
        System.out.println("Expected Messages:");
        System.out.println("  - Where are you? You are late! I have asked you to be on time.");
        System.out.println("  - Ok, I am leaving without you.");
        System.out.println("Found Messages:");
        for (String msg : foundMessages) {
            System.out.println("  - " + msg);
        }
        System.out.println("Result: " + (passed ? "PASSED" : "FAILED"));
        
        return passed;
    }
    
    /**
     * Test 5: Delete a message using message hash
     */
    public boolean testDeleteMessageByHash() {
        populateTestData();
        
        // Find message 2's hash
        String targetHash = null;
        String targetMessage = "Where are you? You are late! I have asked you to be on time.";
        
        for (MessageObject msg : allMessages) {
            if (msg.getMessage().equals(targetMessage)) {
                targetHash = msg.getMessageHash();
                break;
            }
        }
        
        int beforeSize = allMessages.size();
        boolean deleted = deleteMessageByHash(targetHash);
        int afterSize = allMessages.size();
        
        boolean passed = deleted && (beforeSize == afterSize + 1);
        
        System.out.println("\n=== UNIT TEST: Delete Message by Hash ===\n");
        System.out.println("Target Message: \"" + targetMessage + "\"");
        System.out.println("Target Hash: " + targetHash);
        System.out.println("Before deletion - Total messages: " + beforeSize);
        System.out.println("After deletion - Total messages: " + afterSize);
        System.out.println("Result: " + (passed ? "PASSED" : "FAILED"));
        
        return passed;
    }
    
    /**
     * Run all unit tests
     */
    public void runAllUnitTests() {
        System.out.println("\n*************************************************");
        System.out.println("           RUNNING ALL UNIT TESTS");
        System.out.println("*************************************************\n");
        
        boolean test1 = testSentMessagesPopulated();
        boolean test2 = testLongestMessage();
        boolean test3 = testSearchMessageById();
        boolean test4 = testSearchByRecipient();
        boolean test5 = testDeleteMessageByHash();
        
        System.out.println("\n*************************************************");
        System.out.println("           UNIT TEST SUMMARY");
        System.out.println("*************************************************");
        System.out.println("1. Sent Messages Populated: " + (test1 ? "✓ PASS" : "✗ FAIL"));
        System.out.println("2. Longest Message: " + (test2 ? "✓ PASS" : "✗ FAIL"));
        System.out.println("3. Search by Message ID: " + (test3 ? "✓ PASS" : "✗ FAIL"));
        System.out.println("4. Search by Recipient: " + (test4 ? "✓ PASS" : "✗ FAIL"));
        System.out.println("5. Delete by Hash: " + (test5 ? "✓ PASS" : "✗ FAIL"));
        System.out.println("*************************************************\n");
    }
}